#!/usr/bin/env python3.11
"""Contest #2801508 VOXA — build ads, infographic, boards, docs, zip. Usage: python3.11 scripts/build_voxa_deliverables.py [ads|info|boards|docs|all]"""
import json, sys, shutil, zipfile, subprocess
from pathlib import Path
from string import Template
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
G = ROOT / "assets/gallery"
FONTS = (ROOT / "assets/fonts/fonts.css").as_uri()
BUILD = ROOT / "build"; DEL = ROOT / "deliverables"; DOCS = ROOT / "docs"
FACTS = json.loads((ROOT / "client_facts.json").read_text())
for d in (BUILD, DEL, DOCS / "deliverables", DOCS / "exports", ROOT / "exports", ROOT / "review/previews"):
    d.mkdir(parents=True, exist_ok=True)

def gp(name):  # gallery file uri by prefix
    return next(G.glob(name + "*")).as_uri()

IVORY, OBS, BUR, BURD, GOLD = "#F7F3EC", "#0A0809", "#4A0E17", "#26060B", "#C9A96E"
BASE_CSS = f"""
@import url('{FONTS}');
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#000;-webkit-font-smoothing:antialiased}}
:root{{--ivory:{IVORY};--obs:{OBS};--bur:{BUR};--burd:{BURD};--gold:{GOLD}}}
.serif{{font-family:'Cormorant Garamond',serif}} .sans{{font-family:'Plus Jakarta Sans',sans-serif}}
"""

# ---------------------------------------------------------------- Project 1: ads
P1 = FACTS["project_1_speaker_ads"]
ARROW = '<svg class="arr" viewBox="0 0 64 14"><path d="M0 7H62M56 1l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>'
AD_CSS = Template("""
.ad{position:relative;overflow:hidden;width:${W}px;height:${H}px;background:${bg};color:${fg}}
.ph{position:absolute;display:block;max-width:none}
.copy{position:absolute;z-index:3;display:flex;flex-direction:column}
.logo{display:block;width:calc(var(--u)*7);filter:${logofilter}}
.kicker{font:500 calc(var(--u)*.6)/1.4 'Plus Jakarta Sans';letter-spacing:.26em;white-space:pre;color:${kc};margin-top:calc(var(--u)*.7)}
h1{font:500 var(--h)/.9 'Cormorant Garamond';font-weight:500;letter-spacing:-.01em;margin-top:calc(var(--u)*1.5);color:${fg}}
h1 span,h1 em{display:block} h1 em{font-style:italic;color:${hc};font-weight:500}
.rule{width:calc(var(--u)*6);height:1px;background:var(--gold);margin:calc(var(--u)*1.1) 0}
.event{font:italic 500 calc(var(--u)*1.55)/1.15 'Cormorant Garamond';color:${fg}}
.det{margin-top:calc(var(--u)*1.1);font:300 var(--u)/1.5 'Plus Jakarta Sans';letter-spacing:.02em}
.det div{margin-bottom:calc(var(--u)*.55)} .det b{font-weight:500;display:block;letter-spacing:.04em}
.cta{margin-top:auto;display:inline-flex;align-self:flex-start;align-items:center;gap:calc(var(--u)*.9);border:1px solid var(--gold);padding:calc(var(--u)*.8) calc(var(--u)*1.5);font:italic 500 calc(var(--u)*1.55)/1 'Cormorant Garamond';color:${cc}}
.arr{width:calc(var(--u)*2.4);height:auto}
""")

def ad_copy(style=""):
    return f"""<div class="copy" style="{style}"><img class="logo" src="{gp('voxa_gallery_01')}">
<div class="kicker">{P1['kicker'].replace(' | ','  |  ')}</div>
<h1><span>VOXA IS</span><em>SPEAKING</em></h1><div class="rule"></div>
<div class="event">{P1['event_title']}</div>
<div class="det"><div><b>{P1['date']}</b>{P1['time']}</div>
<div><b>{P1['venue_name']}</b>{P1['venue_address']}</div><div>{P1['event_format']}</div></div>
<div class="cta">{P1['cta']}{ARROW}</div></div>"""

# per variant/size: image style, copy style, extra CSS/overlays, --u, --h
AD = {
 ("A","feed"):  dict(img="33", ph="left:60px;top:-400px;width:1333px", copy="left:70px;top:90px;bottom:90px;width:600px", u=27, h=112,
    shade="linear-gradient(90deg,#26060B 0%,rgba(38,6,11,.96) 34%,rgba(74,14,23,.55) 52%,rgba(38,6,11,0) 74%),linear-gradient(0deg,rgba(38,6,11,.75),rgba(38,6,11,0) 28%)"),
 ("A","story"): dict(img="33", ph="left:-160px;top:0;width:1533px", copy="left:80px;top:110px;bottom:110px;width:920px", u=29, h=150,
    shade="linear-gradient(180deg,rgba(38,6,11,.96) 0%,rgba(38,6,11,.8) 24%,rgba(38,6,11,0) 44%),linear-gradient(0deg,#26060B 0%,rgba(38,6,11,.9) 26%,rgba(38,6,11,0) 50%),linear-gradient(90deg,rgba(38,6,11,.8),rgba(38,6,11,0) 55%)"),
 ("A","li"):    dict(img="33", ph="left:470px;top:-344px;width:767px", copy="left:56px;top:40px;bottom:40px;width:520px", u=14.5, h=66,
    shade="linear-gradient(90deg,#26060B 0%,rgba(38,6,11,.97) 38%,rgba(74,14,23,.5) 52%,rgba(38,6,11,0) 70%)"),
 ("B","feed"):  dict(img="22", ph="left:520px;top:60px;width:960px;mix-blend-mode:multiply;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 14%),linear-gradient(180deg,transparent 0,#000 9%);-webkit-mask-composite:source-in", copy="left:70px;top:90px;bottom:90px;width:600px", u=27, h=112, shade=""),
 ("B","story"): dict(img="22", ph="left:0;top:1000px;width:1080px;mix-blend-mode:multiply;-webkit-mask-image:linear-gradient(180deg,transparent 0,#000 12%)", copy="left:80px;top:90px;bottom:90px;width:920px", u=27, h=135, shade="", story_b=True),
 ("B","li"):    dict(img="22", ph="left:690px;top:0;width:520px;mix-blend-mode:multiply;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 14%),linear-gradient(180deg,transparent 0,#000 9%);-webkit-mask-composite:source-in", copy="left:56px;top:40px;bottom:40px;width:560px", u=14.5, h=66, shade=""),
}
SIZES = {"feed": (1080, 1350), "story": (1080, 1920), "li": (1200, 628)}
NAMES = {"feed": "ad_ig_feed_1080x1350", "story": "ad_ig_story_1080x1920", "li": "ad_linkedin_1200x628"}

def ad_html(var, size):
    c = AD[(var, size)]; W, H = SIZES[size]
    if var == "A":
        th = dict(bg=BURD, fg=IVORY, kc=GOLD, hc=GOLD, cc=IVORY, logofilter="none")
    else:
        th = dict(bg=IVORY, fg=OBS, kc="#8A6A2F", hc=BUR, cc=BUR, logofilter="invert(1)")
    css = AD_CSS.substitute(W=W, H=H, **th)
    extra = ""
    if c.get("story_b"):  # keep copy readable: split top copy / bottom details
        extra = ".ad .cta{margin-top:48px}"
    return f"""<!doctype html><meta charset=utf-8><style>{BASE_CSS}{css}{extra}</style>
<div class="ad" style="--u:{c['u']}px;--h:{c['h']}px"><img class="ph" style="{c['ph']}" src="{gp('voxa_gallery_'+c['img'])}">
{'<div style="position:absolute;inset:0;z-index:2;background:'+c['shade']+'"></div>' if c['shade'] else ''}
{ad_copy(c["copy"])}</div>"""

REQUIRED = [P1["kicker"].replace(" | ", "  |  "), "VOXA IS", "SPEAKING", P1["event_title"], P1["date"], P1["time"],
            P1["venue_name"], P1["venue_address"], P1["event_format"], P1["cta"]]
norm = lambda s: " ".join(s.split())

def build_ads(pw):
    b = pw.chromium.launch(); report = {}
    for var in "AB":
        for size, (W, H) in SIZES.items():
            html = BUILD / f"ad_{size}_{var}.html"; html.write_text(ad_html(var, size))
            pg = b.new_page(viewport={"width": W, "height": H}); pg.goto(html.as_uri()); pg.evaluate("document.fonts.ready")
            pg.wait_for_timeout(400)
            txt = norm(pg.evaluate("document.body.textContent"))
            miss = [r for r in REQUIRED if norm(r) not in txt]
            geo = pg.evaluate("""()=>{const a=document.querySelector('.ad').getBoundingClientRect();const c=document.querySelector('.copy');
              const kids=[...c.children].map(e=>e.getBoundingClientRect());const cr=c.getBoundingClientRect();
              return {copyOverflowBottom:Math.max(...kids.map(r=>r.bottom))>a.bottom-10, copyOverflowRight:Math.max(...kids.map(r=>r.right))>a.right-10,
                      vOverlap:kids.some((r,i)=>i&&kids[i-1].bottom>r.top+1)}}""")
            out = DEL / f"{NAMES[size]}_option{var}.jpg"
            pg.screenshot(path=str(out), type="jpeg", quality=95); pg.close()
            report[out.name] = dict(missing_copy=miss, **geo)
    b.close(); return report

# ---------------------------------------------------------------- Project 2: infographic
S = {s["id"]: s for s in FACTS["project_2_infographic"]["sections"]}
INFO_CSS = f"""
{BASE_CSS}
body{{background:{IVORY}}}
@page{{size:2000px 6000px;margin:0}}
.page{{font-variant-numeric:lining-nums;font-feature-settings:'lnum' 1;position:relative;width:2000px;height:6000px;overflow:hidden;background:{IVORY};font-family:'Plus Jakarta Sans'}}
.sec{{position:absolute;left:0;width:2000px;overflow:hidden}}
.sec>.gl{{position:absolute;top:0;bottom:0;width:1px;background:rgba(201,169,110,.35)}}
.sec>.tl{{position:absolute;top:0;left:0;right:0;height:1px;background:rgba(201,169,110,.35);z-index:5}}
.t{{position:absolute;z-index:4}}
.kick{{font:500 26px/1.4 'Plus Jakarta Sans';letter-spacing:.34em;color:{GOLD}}}
.h{{font-family:'Cormorant Garamond';font-weight:500;line-height:.95;letter-spacing:-.01em}}
.body{{font:300 35px/1.62 'Plus Jakarta Sans';letter-spacing:.01em}}
.box{{border:1px solid {GOLD};padding:34px 44px;font:italic 500 56px/1.15 'Cormorant Garamond'}}
.ph{{position:absolute;display:block;object-fit:cover}}
.dark{{background:{OBS};color:{IVORY}}} .bur{{background:#380A12;color:{IVORY}}} .ivo{{background:{IVORY};color:{OBS}}}
"""
def info_html():
    f = lambda k: gp("voxa_gallery_" + k)
    s1, s2, s3, s4, s5, s6 = (S["hero"], S["01"], S["02"], S["03"], S["04"], S["05"])
    gl = '<div class="gl" style="left:100px"></div><div class="gl" style="left:1900px"></div><div class="tl"></div>'
    pil = "".join(f'<span style="white-space:nowrap">{p}</span>' + ('<i style="color:%s;font-style:normal;margin:0 14px">•</i> ' % GOLD if i < 4 else "") for i, p in enumerate(s4["pillars"]))
    return f"""<!doctype html><meta charset=utf-8><style>{INFO_CSS}</style><div class="page">
<!-- 1 HERO -->
<div class="sec ivo" style="top:0;height:1050px">{gl}
 <img class="ph" src="{f('02')}" style="left:1000px;top:0;width:430px;height:1050px;object-position:50% 58%">
 <img class="ph" src="{f('19')}" style="left:1431px;top:0;width:569px;height:1050px;object-position:38% 25%">
 <div class="gl" style="left:1430px;background:{GOLD}"></div>
 <img class="t" src="{gp('voxa_gallery_01')}" style="left:140px;top:70px;width:340px;filter:invert(1)">
 <div class="t kick" style="left:140px;top:175px;color:#8A6A2F">{s1['kicker']}</div>
 <div class="t h" style="left:140px;top:235px;font-size:150px;color:{BUR};width:800px;line-height:.92">{s1['headline']}</div>
 <div class="t h" style="left:140px;top:535px;font-size:56px;font-style:italic;width:820px;line-height:1.1">{s1['subhead']}</div>
 <div class="t body" style="left:140px;top:690px;width:780px;font-size:32px;line-height:1.55">{s1['body']}</div></div>
<!-- 2 TIKTOK -->
<div class="sec dark" style="top:1050px;height:950px">{gl}
 <img class="ph" src="{f('14')}" style="left:1040px;top:0;width:960px;height:950px;object-position:50% 20%;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 40%)">
 <div class="t kick" style="left:140px;top:105px">01 — TIKTOK · LIVE PLATFORM AUTHORITY</div>
 <div class="t h" style="left:140px;top:165px;font-size:104px;width:1000px;color:{IVORY};line-height:.95">{s2['headline']}</div>
 <div class="t body" style="left:140px;top:500px;width:860px;font-size:31px;line-height:1.55">{s2['body']}</div>
 <div class="t box" style="left:140px;top:820px;width:1080px;color:{GOLD};font-size:38px;padding:20px 34px;white-space:nowrap">{s2['highlight']}</div></div>
<!-- 3 INSTAGRAM -->
<div class="sec ivo" style="top:2000px;height:1000px">{gl}
 <img class="ph" src="{f('22')}" style="left:90px;top:40px;width:760px;height:960px;object-fit:cover;object-position:50% 8%;mix-blend-mode:multiply;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 12%,#000 88%,transparent 100%),linear-gradient(180deg,transparent 0,#000 8%);-webkit-mask-composite:source-in">
 <div class="t kick" style="left:960px;top:115px;color:#8A6A2F">02 — INSTAGRAM · AUDIENCE &amp; GROWTH</div>
 <div class="t h" style="left:950px;top:160px;font-size:360px;color:{BUR};white-space:nowrap;line-height:1">350K+</div>
 <div class="t h" style="left:960px;top:560px;font-size:64px;letter-spacing:.28em;color:{OBS}">FOLLOWERS</div>
 <div class="t body" style="left:960px;top:665px;width:880px;font-size:32px">{s3['body']}</div>
 <div class="t box" style="left:960px;top:850px;width:900px;background:{BUR};color:{GOLD};font:500 30px/1.2 'Plus Jakarta Sans';letter-spacing:.16em;text-align:center;padding:30px 20px;white-space:nowrap">{s3['goal_label']}</div></div>
<!-- 4 HOUSE -->
<div class="sec bur" style="top:3000px;height:1000px">{gl}
 <div class="t kick" style="left:140px;top:110px">03 — POWERED BY VOXA HOUSE</div>
 <div class="t h" style="left:140px;top:175px;font-size:118px;width:900px;color:{IVORY}">{s4['subhead']}</div>
 <div class="t sans" style="left:140px;top:470px;width:860px;font:500 22px/2 'Plus Jakarta Sans';letter-spacing:.1em;color:{GOLD}">{pil}</div>
 <div class="t body" style="left:140px;top:610px;width:820px;font-size:32px">{s4['body']}</div>
 <div class="t h" style="left:140px;top:820px;font-size:58px;font-style:italic;width:900px;color:{IVORY}">{s4['highlight']}</div>
 <img class="ph" src="{f('20')}" style="left:1110px;top:120px;width:390px;height:760px;object-position:50% 10%;outline:1px solid {GOLD};outline-offset:14px">
 <img class="ph" src="{gp('voxa_p19_219')}" style="left:1530px;top:120px;width:330px;height:760px;object-position:50% 50%;outline:1px solid {GOLD};outline-offset:14px"></div>
<!-- 5 CHICAGO -->
<div class="sec dark" style="top:4000px;height:1050px">{gl}
 <img class="ph" src="{f('05')}" style="left:880px;top:0;width:1120px;height:1050px;object-position:50% 30%"> 
 <div class="t" style="left:0;top:0;width:2000px;height:1050px;background:linear-gradient(90deg,{OBS} 0,{OBS} 38%,rgba(10,8,9,.55) 52%,rgba(10,8,9,0) 72%)"></div>
 <div class="t kick" style="left:140px;top:95px">04 — CONNECTED IN CHICAGO</div>
 <div class="t h" style="left:140px;top:140px;width:1150px;font-size:54px;letter-spacing:.05em;line-height:1.2;color:{IVORY}"><span style="display:block;font-size:280px;color:{GOLD};letter-spacing:-.02em;line-height:1.05">$100M</span> IN COMBINED ANNUAL REVENUE ACROSS CONNECTED BUSINESSES</div>
 <div class="t body" style="left:140px;top:610px;width:900px;font-size:31px;line-height:1.5">{s5['body']}</div>
 <div class="t h" style="left:140px;top:880px;font-size:46px;font-style:italic;width:1100px;color:{IVORY}">{s5['highlight']}</div>
 <div class="t" style="left:140px;top:972px;font:300 22px 'Plus Jakarta Sans';letter-spacing:.06em;color:rgba(247,243,236,.7)">The $100M figure refers to the connected businesses collectively.</div></div>
<!-- 6 VALUE -->
<div class="sec ivo" style="top:5050px;height:950px">{gl}
 <img class="ph" src="{f('18')}" style="left:1150px;top:60px;width:700px;height:830px;object-position:50% 12%;mix-blend-mode:multiply;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 12%,#000 88%,transparent 100%),linear-gradient(180deg,transparent 0,#000 8%,#000 92%,transparent 100%);-webkit-mask-composite:source-in">
 <div class="t kick" style="left:140px;top:105px;color:#8A6A2F">05 — THE BRAND VALUE</div>
 <div class="t h" style="left:140px;top:165px;font-size:130px;width:1000px;color:{BUR}">{s6['subhead']}</div>
 <div class="t body" style="left:140px;top:430px;width:920px;font-size:31px;line-height:1.55">{s6['body']}</div>
 <div class="t" style="left:140px;top:720px;width:960px;background:{OBS};border:1px solid {GOLD};padding:34px 20px;text-align:center;white-space:nowrap;font:500 46px/1.1 'Cormorant Garamond';letter-spacing:.05em;color:{IVORY}">{s6['closing_headline']}</div>
 <div class="t" style="left:140px;top:885px;font:500 24px 'Plus Jakarta Sans';letter-spacing:.34em;color:#8A6A2F;white-space:pre">{s6['footer'].replace(' | ','  |  ')}</div></div>
</div>"""

def build_info(pw):
    html = BUILD / "infographic.html"; html.write_text(info_html())
    b = pw.chromium.launch(); pg = b.new_page(viewport={"width": 2000, "height": 6000}); pg.goto(html.as_uri())
    pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(800)
    pg.screenshot(path=str(DEL / "voxa_longform_infographic_2000x6000.png"), type="png")
    pg.screenshot(path=str(DEL / "voxa_longform_infographic_2000x6000.jpg"), type="jpeg", quality=95)
    pg.pdf(path=str(DEL / "VOXA_Brand_Partner_Infographic.pdf"), width="2000px", height="6000px", print_background=True)
    txt = norm(pg.evaluate("document.body.textContent"))
    need = ["A1-CAPABLE BATTLER & STREAMER", "350K+", "FOLLOWERS", "2027 GOAL: 1 MILLION FOLLOWERS", "$100M IN COMBINED ANNUAL REVENUE ACROSS CONNECTED BUSINESSES",
            "A HIGH-VALUE CREATIVE PARTNER.", "The $100M figure refers to the connected businesses collectively.", "WHO IS VOXA?", "Audience. Access. Execution."]
    bad = [n for n in need if norm(n) not in txt]
    sec_over = pg.evaluate("""()=>[...document.querySelectorAll('.t')].filter(e=>{const s=e.closest('.sec').getBoundingClientRect(),r=e.getBoundingClientRect();return r.bottom>s.bottom-20||r.right>s.right-100}).map(e=>e.textContent.slice(0,30))""")
    former = "FORMER" in txt.upper()
    b.close(); return dict(missing=bad, text_over_section=sec_over, has_FORMER=former)

# ---------------------------------------------------------------- boards (3200x2400)
BOARD_CSS = f"""{BASE_CSS}
body{{width:3200px;height:2400px;background:{OBS};color:{IVORY};position:relative;overflow:hidden;font-family:'Plus Jakarta Sans'}}
.a{{position:absolute}} img.a{{display:block}}
.label{{position:absolute;font:500 22px/1 'Plus Jakarta Sans';letter-spacing:.3em;color:{GOLD};white-space:nowrap}}
.t{{overflow:hidden}}
.fr{{outline:1px solid rgba(201,169,110,.55);outline-offset:0}}
.crop{{position:absolute;overflow:hidden;outline:1px solid rgba(201,169,110,.55);background-repeat:no-repeat}}
"""
def dv(n): return (DEL / n).as_uri()
AD_F = {v: {s: dv(f"{NAMES[s]}_option{v}.jpg") for s in SIZES} for v in "AB"}
INFO = dv("voxa_longform_infographic_2000x6000.jpg")
def L(x, y, t, extra=""): return f'<div class="label" style="left:{x}px;top:{y}px;{extra}">{t}</div>'
def IM(src, x, y, w, h, cls="fr"): return f'<img class="a {cls}" src="{src}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px">'
def CROP(x, y, w, h, sx, sy, sw):  # show source rect starting (sx,sy) of width sw from infographic
    k = w / sw
    return f'<div class="crop" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;background-image:url({INFO});background-size:{2000*k}px {6000*k}px;background-position:{-sx*k}px {-sy*k}px"></div>'

def board1():
    h = IM(AD_F["A"]["feed"], 50, 50, 1072, 1340) + IM(AD_F["A"]["story"], 1146, 50, 754, 1340)
    h += IM(AD_F["A"]["li"], 50, 1414, 1100, 575) + IM(AD_F["B"]["feed"], 1174, 1414, 460, 575)
    h += IM(INFO, 2410, 50, 740, 2220)
    h += CROP(1924, 50, 462, 430, 120, 1140, 920) + CROP(1924, 505, 462, 470, 930, 2080, 930) + CROP(1924, 1000, 462, 330, 120, 4100, 1180)
    h += f'<div class="a" style="left:50px;top:2030px;width:1850px;height:1px;background:rgba(201,169,110,.5)"></div>'
    h += f'<div class="a t" style="left:50px;top:2065px;width:900px;height:70px;font:500 60px/1.1 \'Cormorant Garamond\';white-space:nowrap">VOXA<span style="font-style:italic;color:{GOLD}"> House</span></div>'
    h += L(50, 2175, "SPEAKER ANNOUNCEMENT SUITE — IG FEED · IG STORY · LINKEDIN") + L(50, 2215, "INTRODUCING VOXA — 2000 × 6000 LONG-FORM INFOGRAPHIC")
    h += L(1924, 2065, "CONTEST #2801508") + L(1924, 2105, "OFFICIAL GALLERY PHOTOS ONLY", "font-size:18px;letter-spacing:.2em;color:rgba(247,243,236,.7)")
    return h
def board2():
    h = ""
    for v, y, name in (("A", 60, "OPTION A — CHICAGO BRIDGE, BLACK & WHITE EDITORIAL"), ("B", 1215, "OPTION B — BURGUNDY LEATHER TRENCH, STUDIO COUTURE")):
        h += L(70, y, name) + IM(AD_F[v]["feed"], 70, y + 45, 816, 1020) + IM(AD_F[v]["story"], 910, y + 45, 574, 1020)
        h += IM(AD_F[v]["li"], 1508, y + 45, 1620, 848)
        h += L(1508, y + 925, "LINKEDIN 1200 × 628  ·  IG FEED 1080 × 1350  ·  IG STORY 1080 × 1920", "color:rgba(247,243,236,.7)")
    return h
def board3():
    h = IM(INFO and dv("voxa_longform_infographic_2000x6000.jpg"), 0, 0, 1, 1) if False else ""
    for i, (y0, t) in enumerate(((0, "PART I — HERO · 01 TIKTOK · 02 INSTAGRAM"), (3000, "PART II — 03 VOXA HOUSE · 04 CHICAGO · 05 BRAND VALUE"))):
        x = 113 + i * (1467 + 40) ; w, hh = 1467, 2200
        h += L(x, 40, t) + f'<div class="crop" style="left:{x}px;top:90px;width:{w}px;height:{hh}px;background-image:url({INFO});background-size:{w}px {w*3}px;background-position:0 {-y0*w/2000}px"></div>'
        h += L(x, 2320, f"Y = {y0} – {y0+3000} PX OF 2000 × 6000", "color:rgba(247,243,236,.7)")
    return h
def board4():
    h = ""
    cs = (("Ivory", IVORY), ("Obsidian Black", OBS), ("Deep Burgundy", BUR), ("Pure White", "#FFFFFF"), ("Champagne Gold", GOLD))
    h += L(100, 90, "EDITORIAL SPECIFICATION")
    h += f'<div class="a" style="left:100px;top:150px;width:1400px;font:500 300px/1.1 \'Cormorant Garamond\'">Aa <span style="font-style:italic;color:{GOLD}">Aa</span></div>'
    h += f'<div class="a t" style="left:100px;top:490px;width:1450px;font:500 96px/1.2 \'Cormorant Garamond\'">VOXA IS <i style="color:{GOLD}">SPEAKING</i></div>'
    h += f'<div class="a t" style="left:100px;top:620px;width:1450px;font:500 24px/1.6 \'Plus Jakarta Sans\';letter-spacing:.3em;color:{GOLD}">VOXA HOUSE  |  SPEAKER ANNOUNCEMENT</div>'
    h += f'<div class="a t" style="left:100px;top:690px;width:1350px;font:300 32px/1.6 \'Plus Jakarta Sans\'">Display: Cormorant Garamond 500 / 500 italic — high-contrast serif for headlines and the 350K+ · 1 MILLION · $100M numerals. Text and kickers: Plus Jakarta Sans 300–500, tracking 0.26–0.34em for kickers. No pill badges, no coloured edge bars, no glass bubbles.</div>'
    h += L(100, 900, "PALETTE")
    for i, (n, c) in enumerate(cs):
        x = 100 + i * 290
        h += f'<div class="a fr" style="left:{x}px;top:950px;width:260px;height:260px;background:{c}"></div>' + L(x, 1235, n.upper(), "font-size:15px;letter-spacing:.18em;color:%s" % IVORY) + L(x, 1265, c, "font-size:17px;letter-spacing:.1em;color:rgba(247,243,236,.7)")
    h += L(100, 1360, "DELIVERABLES")
    rows = ["ad_ig_feed_1080x1350  ·  option A / B  (JPG)", "ad_ig_story_1080x1920  ·  option A / B  (JPG)", "ad_linkedin_1200x628  ·  option A / B  (JPG)",
            "voxa_longform_infographic_2000x6000  (JPG · PNG)", "VOXA_Brand_Partner_Infographic  (PDF, live text)", "board1 – board4  (3200 × 2400 JPG)", "VOXA_Luxury_Social_Ads_Infographic_Master_Pack.zip"]
    for i, r in enumerate(rows):
        h += f'<div class="a t" style="left:100px;top:{1415+i*72}px;width:1450px;font:300 30px/1 \'Plus Jakarta Sans\';padding-bottom:20px;border-bottom:1px solid rgba(201,169,110,.35)">{r}</div>'
    # gallery index
    h += L(1700, 90, "OFFICIAL GALLERY PHOTOGRAPHS USED — vvoxxaa.com/gallery")
    used = [("02", "Studio gown"), ("19", "Fur coat"), ("14", "White shirt"), ("22", "Burgundy trench"), ("20", "Black gown"), ("18", "Black dress"), ("05", "Bridge, colour"), ("33", "Bridge, B&W")]
    for i, (k, n) in enumerate(used):
        x = 1700 + (i % 4) * 375; y = 150 + (i // 4) * 640
        h += f'<img class="a fr" src="{gp("voxa_gallery_"+k)}" style="left:{x}px;top:{y}px;width:340px;height:500px;object-fit:cover;object-position:50% 25%">'
        h += L(x, y + 520, f"gallery_{k}", "font-size:18px") + L(x, y + 552, n.upper(), "font-size:15px;letter-spacing:.18em;color:rgba(247,243,236,.7)")
    h += L(1700, 1450, "LOGOS AND SUPPORT")
    h += f'<img class="a" src="{gp("voxa_gallery_01")}" style="left:1700px;top:1510px;width:460px">'
    h += f'<img class="a fr" src="{gp("voxa_p2_45")}" style="left:2240px;top:1480px;width:200px;height:200px">'
    h += f'<img class="a fr" src="{gp("voxa_p19_219")}" style="left:2500px;top:1480px;width:300px;height:200px;object-fit:cover">'
    h += L(1700, 1780, "voxa_gallery_01 · voxa_p2_45 · voxa_p19_219", "font-size:17px;color:rgba(247,243,236,.7)")
    h += f'<div class="a t" style="left:1700px;top:1900px;width:1400px;font:300 28px/1.6 \'Plus Jakarta Sans\'">Photography: official VOXA gallery originals only, no generated or substitute imagery. Option A keeps the client reference skeleton (burgundy left panel, bridge photograph, Register Now) with the orange wedge, badge icons and gradient button removed.</div>'
    return h

def build_boards(pw):
    b = pw.chromium.launch(); rep = {}
    names = {1: ("board1_hero_infographic_and_speaker_suite", board1), 2: ("board2_speaker_ads_3sizes_ab_options", board2),
             3: ("board3_longform_infographic_2split", board3), 4: ("board4_editorial_spec_and_deliverables", board4)}
    for i, (n, fn) in names.items():
        html = BUILD / f"board{i}.html"; html.write_text(f"<!doctype html><meta charset=utf-8><style>{BOARD_CSS}</style>{fn()}")
        pg = b.new_page(viewport={"width": 3200, "height": 2400}); pg.goto(html.as_uri()); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(800)
        rep[n] = pg.evaluate("""()=>{const W=innerWidth,H=innerHeight;const els=[...document.querySelectorAll('body *')];
          const overflow=[...document.querySelectorAll('.t')].filter(e=>e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+1).map(e=>e.textContent.slice(0,40));
          const outside=els.filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.left<-.5||r.top<-.5||r.right>W+.5||r.bottom>H+.5)}).length;
          const labs=[...document.querySelectorAll('.label')].map(e=>e.getBoundingClientRect());let ov=0;
          for(let i=0;i<labs.length;i++)for(let j=i+1;j<labs.length;j++){const a=labs[i],b=labs[j];if(a.left<b.right&&b.left<a.right&&a.top<b.bottom&&b.top<a.bottom)ov++}
          return {overflow,outside,labelOverlaps:ov}}""")
        pg.screenshot(path=str(DEL / f"{n}.jpg"), type="jpeg", quality=93); pg.close()
    b.close(); return rep

# ---------------------------------------------------------------- docs + zip
DOC_HTML = """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VOXA — Speaker Ads &amp; Infographic</title>
<link rel="stylesheet" href="../assets/fonts/fonts.css">
<style>*{margin:0;box-sizing:border-box}body{background:#0A0809;color:#F7F3EC;font:300 16px/1.6 'Plus Jakarta Sans',sans-serif}
header{padding:48px 6vw 24px;border-bottom:1px solid rgba(201,169,110,.35)}h1{font:500 56px/1 'Cormorant Garamond',serif}h1 i{color:#C9A96E}
.k{font:500 12px 'Plus Jakarta Sans';letter-spacing:.3em;color:#C9A96E;margin-bottom:12px}
nav{display:flex;gap:32px;padding:16px 6vw;border-bottom:1px solid rgba(201,169,110,.35);position:sticky;top:0;background:#0A0809;z-index:5}
nav button,.sub button{background:none;border:0;border-bottom:1px solid transparent;color:#F7F3EC;font:500 12px 'Plus Jakarta Sans';letter-spacing:.24em;padding:6px 0;cursor:pointer}
nav button.on,.sub button.on{border-color:#C9A96E;color:#C9A96E}
section{display:none;padding:32px 6vw 80px}section.on{display:block}.sub{display:flex;gap:28px;margin-bottom:24px}
img{max-width:100%;display:block;outline:1px solid rgba(201,169,110,.4)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:28px}
.view{max-width:1100px}.long{max-width:700px;margin:0 auto}a{color:#C9A96E}.dl{display:inline-block;margin-top:20px;border:1px solid #C9A96E;padding:14px 28px;font:italic 500 22px 'Cormorant Garamond';text-decoration:none}</style>
<header><div class="k">CONTEST #2801508 · VOXA HOUSE</div><h1>VOXA <i>Speaker Ads</i> &amp; Infographic</h1></header>
<nav><button class="on" data-t="p1">PROJECT 1 — SPEAKER ADS</button><button data-t="p2">PROJECT 2 — INFOGRAPHIC</button><button data-t="bd">BOARDS</button><button data-t="dl">DOWNLOAD</button></nav>
<section id="p1" class="on"><div class="sub" id="opt"><button class="on" data-o="A">OPTION A — CHICAGO BRIDGE</button><button data-o="B">OPTION B — STUDIO COUTURE</button></div>
<div class="grid"><div><div class="k">IG FEED 1080 × 1350</div><img id="f"></div><div><div class="k">IG STORY 1080 × 1920</div><img id="s"></div><div style="grid-column:1/-1"><div class="k">LINKEDIN 1200 × 628</div><img id="l" class="view"></div></div></section>
<section id="p2"><div class="sub" id="zm"><button class="on" data-z="fit">FIT</button><button data-z="full">FULL SIZE 2000 PX</button></div><div id="lw"><img id="lg" class="long" src="deliverables/voxa_longform_infographic_2000x6000.jpg"></div></section>
<section id="bd"><div class="grid" style="grid-template-columns:1fr">
<img src="deliverables/board1_hero_infographic_and_speaker_suite.jpg"><img src="deliverables/board2_speaker_ads_3sizes_ab_options.jpg"><img src="deliverables/board3_longform_infographic_2split.jpg"><img src="deliverables/board4_editorial_spec_and_deliverables.jpg"></div></section>
<section id="dl"><p>Master pack: ads (A/B × 3 sizes), 2000 × 6000 infographic (JPG, PNG, PDF), four 3200 × 2400 boards.</p><a class="dl" href="exports/VOXA_Luxury_Social_Ads_Infographic_Master_Pack.zip" download>Download .zip</a>
<p style="margin-top:24px"><a href="deliverables/VOXA_Brand_Partner_Infographic.pdf">Infographic PDF</a> · <a href="deliverables/voxa_longform_infographic_2000x6000.png">Infographic PNG</a></p></section>
<script>const N={f:'ad_ig_feed_1080x1350',s:'ad_ig_story_1080x1920',l:'ad_linkedin_1200x628'};let O='A';
function ads(){for(const k in N)document.getElementById(k).src='deliverables/'+N[k]+'_option'+O+'.jpg'}ads();
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('nav button,section').forEach(e=>e.classList.remove('on'));b.classList.add('on');document.getElementById(b.dataset.t).classList.add('on')});
document.querySelectorAll('#opt button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#opt button').forEach(e=>e.classList.remove('on'));b.classList.add('on');O=b.dataset.o;ads()});
document.querySelectorAll('#zm button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#zm button').forEach(e=>e.classList.remove('on'));b.classList.add('on');const g=document.getElementById('lg');g.style.maxWidth=b.dataset.z=='full'?'none':'700px';g.style.width=b.dataset.z=='full'?'2000px':'';document.getElementById('lw').style.overflow='auto'})</script></html>"""

def build_docs():
    (DOCS / "index.html").write_text(DOC_HTML)
    (DOCS / "assets").mkdir(exist_ok=True)
    shutil.copytree(ROOT / "assets/fonts", DOCS / "assets/fonts", dirs_exist_ok=True)
    (DOCS / "index.html").write_text(DOC_HTML.replace("../assets/fonts/fonts.css", "assets/fonts/fonts.css"))
    z = ROOT / "exports/VOXA_Luxury_Social_Ads_Infographic_Master_Pack.zip"
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(DEL.iterdir()): zf.write(p, f"deliverables/{p.name}")
        zf.write(ROOT / "client_facts.json", "client_facts.json"); zf.write(Path(__file__), "scripts/build_voxa_deliverables.py")
    for p in DEL.iterdir(): shutil.copy2(p, DOCS / "deliverables" / p.name)
    shutil.copy2(z, DOCS / "exports" / z.name)

if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    rep = {}
    with sync_playwright() as pw:
        if what in ("ads", "all"): rep["ads"] = build_ads(pw)
        if what in ("info", "all"): rep["info"] = build_info(pw)
        if what in ("boards", "all"): rep["boards"] = build_boards(pw)
    if what in ("docs", "all"):
        build_docs()
        import importlib.util
        sp = importlib.util.spec_from_file_location("mp", str(ROOT.parent.parent / "scripts/make_preview.py")); mp = importlib.util.module_from_spec(sp); sp.loader.exec_module(mp)
        for b in sorted(DEL.glob("board*.jpg")): print(mp.make_preview(str(b), 1200, str(ROOT / "review/previews")))
    print(json.dumps(rep, indent=1, ensure_ascii=False))
